<div class="rows">

    <div class="panel panel-primary">

        <div class="panel-body">
            
            <div class="rows">

                <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">

                    <h3 style="text-align: center">CAJA DE JUBILACIONES Y PENSIONES DEL PERSONAL MUNICIPAL</h3>
                    <br>
                    <h4 style="text-align: center"> CONSTANCIA DE APORTE</h4>                       

                </div>

            </div>

        </div>
    
    </div>

<div class="row">

    <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
        <div class="form-group">
            <p style="border: ridge #0f0fef 1px;"> 
            <label form="nombre" > <h4> Afiliado :</h4></label></p>
            <br>
            <label> <h5> <b><?php echo e($user->name); ?> </b> </h5> </label>
        </div>
    </div>

</div><?php /**PATH E:\JuegosySofwareinstalado\laragon\www\anr\resources\views/pdf\user.blade.php ENDPATH**/ ?>