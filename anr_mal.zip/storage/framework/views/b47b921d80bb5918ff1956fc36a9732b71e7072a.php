<?php
    $total_voto = 0
?>

<?php if(empty($aux->cont)): ?>

<?php else: ?>

    <?php $__currentLoopData = $votacion_intendente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php $total_voto += $vota->Votos  ?>        
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">            
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>

    <header>
        
        <p><strong>ANR</strong></p>    

    </header>
    
    <div class="container">

        <u><h3 align="center" ><strong>Resumen General de Votos</strong></h3></u>
        
        <br>        

        <?php if(empty($aux->cont)): ?>

        <?php else: ?>        

            <div class="table table-responsive table-bordered">
                
                <table class="table">
                
                    <thead class="thead-light">                    

                        <tr style="text-align: center">
                            <th scope="col">Lista</th>
                            <th scope="col">Intendente</th>
                            <th scope="col">Votos</th>
                        </tr>
                    </thead>
                    
                    <tbody>
                        <?php $__currentLoopData = $votacion_intendente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr style="text-align: center">
                                
                                <th scope="row"><?php echo e($vot->Desc_Lista); ?></th>
                                <td><?php echo e($vot->Nombre); ?> <?php echo e($vot->Apellido); ?></td>
                                <td style="text-align: right"><?php echo e(number_format($vot->Votos,0, ".", ".")); ?></td>
                                
                            </tr>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    


                    </tbody>

                    <tfoot>

                        <tr>

                            <td colspan="2">Total de Votos</td> 
                            <td style="text-align: right"> <b><?php echo e(number_format($total_voto,0, ".", ".")); ?> </b></td>

                        </tr>
                    
                    </tfoot>

                </table>

            </div>
            
        <?php endif; ?>

    </div>
    
    
</body>
</html>
<?php /**PATH E:\JuegosySofwareinstalado\laragon\www\anr\resources\views/pdf\intendente_resumen.blade.php ENDPATH**/ ?>