<?php $local_1 = 0 ?>

<?php $local_2 = 0 ?>

<?php $local_3 = 0 ?>

<?php $local_4 = 0 ?>

<?php $local_5 = 0 ?>

<?php $total_general = 0 ?>

<?php $__currentLoopData = $consejal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php if($res->Id_Local == 1): ?>

        <?php $local_1 += $res->Votos ?>           

    <?php endif; ?>

    <?php if($res->Id_Local == 2): ?>

        <?php $local_2 += $res->Votos ?>           

    <?php endif; ?>
    
    <?php if($res->Id_Local == 3): ?>

        <?php $local_3 += $res->Votos ?>           

    <?php endif; ?>

    <?php if($res->Id_Local == 4): ?>

        <?php $local_4 += $res->Votos ?>

    <?php endif; ?>

    <?php if($res->Id_Local == 5): ?>

        <?php $local_5 += $res->Votos ?>           

    <?php endif; ?>

    <?php $total_general += $res->Votos ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">            
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>

    <header>
        
        <p><strong>ANR</strong></p>    

    </header>
    
    <div class="container">

        <u><h3 align="center" ><strong>Resumen de Votos de: <?php echo e($aux_consejal->Nombre); ?> <?php echo e($aux_consejal->Apellido); ?></strong></h3></u>
        
        <br>                
        
        <?php $__currentLoopData = $local_votacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <div class="table table-responsive table-bordered">
                    
                <table class="table">
                                                        
                    <thead class="thead-light">                    

                        <tr style="text-align: center">
                            
                            <th colspan="2"><?php echo e($loca->Desc_Local); ?></th>
                            
                        </tr>
                        <tr style="text-align: center">

                            <th scope="col">Mesa</th>                                
                            <th scope="col">Votos</th>

                        </tr>

                    </thead>

                    <tbody>

                        <?php $__currentLoopData = $consejal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php if($conse->Id_Local == $loca->Id_Local): ?>
                                
                                <tr style="text-align: center">
                                    
                                    <th scope="row"><?php echo e($conse->Mesa); ?></th>                                    
                                    <td style="text-align: right"><?php echo e(number_format($conse->Votos,0, ".", ".")); ?></td>
                                    
                                </tr>

                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>

                    <tfoot>

                        <tr>

                            <th scope="row">Total de Votos</th>
                            
                            <?php if($loca->Id_Local == 1): ?>
                                
                                <td style="text-align: right"> <b><?php echo e(number_format($local_1, 0, ".", ".")); ?> </b></td>

                            <?php endif; ?>
                            
                            <?php if($loca->Id_Local == 2): ?>
                                
                                <td style="text-align: right"> <b><?php echo e(number_format($local_2, 0, ".", ".")); ?> </b></td>

                            <?php endif; ?>

                            <?php if($loca->Id_Local == 3): ?>
                                
                                <td style="text-align: right"> <b><?php echo e(number_format($local_3, 0, ".", ".")); ?> </b></td>

                            <?php endif; ?>
                            
                            <?php if($loca->Id_Local == 4): ?>
                                
                                <td style="text-align: right"> <b><?php echo e(number_format($local_4, 0, ".", ".")); ?> </b></td>

                            <?php endif; ?>
                            
                            <?php if($loca->Id_Local == 5): ?>
                                
                                <td style="text-align: right"> <b><?php echo e(number_format($local_5, 0, ".", ".")); ?> </b></td>

                            <?php endif; ?>

                        </tr>
                    
                    </tfoot>                    

                </table>

            </div>
            
            <br>            

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="table table-responsive table-bordered">
                    
            <table class="table">
                                                    
                <thead class="thead-light">

                    <tr style="text-align: center">

                        <th scope="col"> <b> TOTAL GENERAL DE VOTOS: </b></th>
                        <th scope="col"><?php echo e(number_format($total_general, 0, ".", ".")); ?> </th>

                    </tr>

                </thead>
            
            </table>   
        
        </div>
    
    </div>    
    
</body>

</html><?php /**PATH E:\JuegosySofwareinstalado\laragon\www\anr\resources\views/pdf\consejal.blade.php ENDPATH**/ ?>