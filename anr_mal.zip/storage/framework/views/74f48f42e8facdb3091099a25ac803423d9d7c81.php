

<?php $__env->startSection('contenido'); ?>

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

    <img src="<?php echo e(asset('imagenes/acta/'.$votos_consejal->imagen)); ?>" alt="<?php echo e($votos_consejal->imagen); ?>" 
    height="500 px" width="500 px" class="img-thumbnail">
    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\JuegosySofwareinstalado\laragon\www\anr\resources\views/consulta\votos_consejal/acta.blade.php ENDPATH**/ ?>