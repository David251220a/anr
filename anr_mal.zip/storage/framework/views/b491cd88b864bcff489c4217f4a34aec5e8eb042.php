<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">            
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>

    <header>
        
        <p><strong>ANR</strong></p>    

    </header>
    
    <div class="container">

        <u><h3 align="center" ><strong>Resumen de Votos Consejal por Mesa</strong></h3></u>
        
        <br>                
        
        <?php $__currentLoopData = $consejal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $int): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="table table-responsive table-bordered">
                
                <table class="table">
                                                        
                    <thead class="thead-light">                    

                        <tr style="text-align: center">
                            
                            <th colspan="2"><?php echo e($int->Nombre); ?> <?php echo e($int->Apellido); ?></th>
                            
                        </tr>
                        <tr style="text-align: center">

                            <th scope="col">Mesa</th>                                
                            <th scope="col">Votos</th>

                        </tr>

                    </thead>

                    <tbody>

                        <?php $__currentLoopData = $resumen_mesa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php if($int->Id_Consejal == $resu->Id_Consejal): ?>
                                
                                <tr style="text-align: center">
                                    
                                    <th scope="row"><?php echo e($resu->Mesa); ?></th>                                    
                                    <td style="text-align: right"><?php echo e(number_format($resu->Votos,0, ".", ".")); ?></td>
                                    
                                </tr>

                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                                          
                    <?php $__currentLoopData = $total; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                        <?php if($int->Id_Consejal == $tota->Id_Consejal): ?>
                        
                            <?php if(empty($tota->Votos)): ?>                                    
                                
                            <?php else: ?>
                            
                                <tfoot>

                                    <tr style="text-align: center">
                                        <th scope="row">Total de Votos</th>             
                                        <td style="text-align: right"><?php echo e(number_format($resu->Votos,0, ".", ".")); ?></td>
                                        
                                    </tr>
                                
                                </tfoot>
                            
                            <?php endif; ?>

                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    

                </table>

            </div>
            
            <br>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>    
    
</body>
</html>
<?php /**PATH E:\JuegosySofwareinstalado\laragon\www\anr\resources\views/pdf\consejal_mesa_resumen.blade.php ENDPATH**/ ?>