<meta http-equiv="refresh" content="0; votacion/intendente">
<?php /**PATH E:\JuegosySofwareinstalado\laragon\www\anr_mal\resources\views/home.blade.php ENDPATH**/ ?>