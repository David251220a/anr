<meta http-equiv="refresh" content="0; votacion/intendente">
<?php /**PATH E:\JuegosySofwareinstalado\laragon\www\anr\resources\views/home.blade.php ENDPATH**/ ?>