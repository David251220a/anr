<?php $intendente_voto_1 = 0 ?>

<?php $intendente_voto_2 = 0 ?>

<?php $intendente_voto_3 = 0 ?>

<?php $intendente_voto_4 = 0 ?>

<?php $intendente_voto_5 = 0 ?>

<?php $__currentLoopData = $resumen_mesa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php if($res->Id_Intendente == 1): ?>

        <?php $intendente_voto_1 += $res->Votos ?>           

    <?php endif; ?>

    <?php if($res->Id_Intendente == 2): ?>

        <?php $intendente_voto_2 += $res->Votos ?>           

    <?php endif; ?>
    
    <?php if($res->Id_Intendente == 3): ?>

        <?php $intendente_voto_3 += $res->Votos ?>           

    <?php endif; ?>

    <?php if($res->Id_Intendente == 4): ?>

        <?php $intendente_voto_4 += $res->Votos ?>

    <?php endif; ?>

    <?php if($res->Id_Intendente == 5): ?>

        <?php $intendente_voto_5 += $res->Votos ?>           

    <?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">            
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>

    <header>
        
        <p><strong>ANR</strong></p>    

    </header>
    
    <div class="container">

        <u><h3 align="center" ><strong>Resumen de Votos Intendente por Mesa</strong></h3></u>
        
        <br>                
        
        <?php $__currentLoopData = $intendente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $int): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="table table-responsive table-bordered">
                
                <table class="table">
                                                        
                    <thead class="thead-light">                    

                        <tr style="text-align: center">
                            
                            <th colspan="2"><?php echo e($int->Nombre); ?> <?php echo e($int->Apellido); ?></th>
                            
                        </tr>
                        <tr style="text-align: center">

                            <th scope="col">Mesa</th>                                
                            <th scope="col">Votos</th>

                        </tr>

                    </thead>

                    <tbody>

                        <?php $__currentLoopData = $resumen_mesa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php if($int->Id_Intendente == $resu->Id_Intendente): ?>
                                
                                <tr style="text-align: center">
                                    
                                    <th scope="row"><?php echo e($resu->Mesa); ?></th>                                    
                                    <td style="text-align: right"><?php echo e(number_format($resu->Votos,0, ".", ".")); ?></td>
                                    
                                </tr>

                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>

                    <tfoot>

                        <tr>

                            <th scope="row">Total de Votos</th>
                            
                            <?php if($int->Id_Intendente == 1): ?>
                                
                                <td style="text-align: right"> <b><?php echo e(number_format($intendente_voto_1,0, ".", ".")); ?> </b></td>

                            <?php endif; ?>
                            
                            <?php if($int->Id_Intendente == 2): ?>
                                
                                <td style="text-align: right"> <b><?php echo e(number_format($intendente_voto_2,0, ".", ".")); ?> </b></td>

                            <?php endif; ?>

                            <?php if($int->Id_Intendente == 3): ?>
                                
                                <td style="text-align: right"> <b><?php echo e(number_format($intendente_voto_3, 0, ".", ".")); ?> </b></td>

                            <?php endif; ?>
                            
                            <?php if($int->Id_Intendente == 4): ?>
                                
                                <td style="text-align: right"> <b><?php echo e(number_format($intendente_voto_4, 0, ".", ".")); ?> </b></td>

                            <?php endif; ?>
                            
                            <?php if($int->Id_Intendente == 5): ?>
                                
                                <td style="text-align: right"> <b><?php echo e(number_format($intendente_voto_5, 0, ".", ".")); ?> </b></td>

                            <?php endif; ?>
                        </tr>
                    
                    </tfoot>                    

                </table>

            </div>
            
            <br>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>    
    
</body>
</html>
<?php /**PATH E:\JuegosySofwareinstalado\laragon\www\anr\resources\views/pdf\intendente_mesa_resumen.blade.php ENDPATH**/ ?>