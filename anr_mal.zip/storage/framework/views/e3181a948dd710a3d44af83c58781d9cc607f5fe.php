

<?php $__env->startSection('contenido'); ?>

<div class="rows">

    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 ">

        <h3>Listado de Usuario  <a href="usuario/create"> <a href="" data-target="#modal-edit" data-toggle="modal">
            <button class="btn btn-success">Nuevo</button>
       </a></h3>
        <?php echo $__env->make('acceso.usuario.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('acceso.usuario.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>

</div>

<div class="rows">

    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <?php if(session()->has('msj')): ?>
        
        <div class="alert alert-danger" role="alert"><?php echo e(session('msj')); ?></div>
        
        <?php else: ?>
            
        <?php endif; ?>
    </div>
</div>

    <div class="rows">

        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

            <div class="table-responsive">

                <table class="table table-striped table-bordered table-condensed table-hover">

                    
                    
                    <thead>

                        <th>Nombre</th>
                        <th>Correo</th>
                        <th>Opciones</th>

                    </thead>
                                        
                    <?php $__currentLoopData = $usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <td><?php echo e($usu->name); ?></td>
                        <td><?php echo e($usu->email); ?></td>
                        <td>
                            
                            <a href="" data-target="#modal-delete-<?php echo e($usu->id); ?>" data-toggle="modal">
                            <button class="btn btn-danger">Cambiar Contraseña</button>
                            </a>
                           
                        </td>
                    </tr>                    

                    <?php echo $__env->make('acceso.usuario.modal_contraseña', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </table>

            </div>

            <?php echo e($usuario -> render()); ?>


        </div>

    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\JuegosySofwareinstalado\laragon\www\anr\resources\views/acceso\usuario/index.blade.php ENDPATH**/ ?>