

<?php $__env->startSection('contenido'); ?>

<div class="rows">

    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        
        <LEGEND><b> <i> <u><h3>Votos Intendente</h3></u></i></b> </LEGEND>

    </div>
</div>

<div class="rows">

    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <?php if(session()->has('msj')): ?>
        
        <div class="alert alert-danger" role="alert"><?php echo e(session('msj')); ?></div>
        
        <?php else: ?>
            
        <?php endif; ?>
    </div>
</div>

<br>

<div class="rows">

    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

        <div class="table table-responsive">

            <table id="detalles"  class="table table-striped table-bordered table-condensed table-hover">                
                
                <thead style="background-color:#f20a0ade">
                    
                    <th style="text-align: center">Lista</th>                                                
                    <th colspan="2" style="text-align: center">Intendente</th>
                    <th style="text-align: center">Local</th>
                    <th style="text-align: center">Mesa</th>
                    <th style="text-align: center">Votos</th>
                    <th style="text-align: center">Opcion</th>
                    <th style="text-align: center">Acta</th>

                </thead>                
                <?php $__currentLoopData = $votos_intendente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr style="vertical-align: middle ; text-align: center">
                                            
                        <td><?php echo e($vot->Desc_Lista); ?></td>                    
                        <td><?php echo e($vot->Nombre); ?></td>
                        <td><?php echo e($vot->Apellido); ?></td>
                        <td><?php echo e($vot->Desc_Local); ?></td>
                        <td><?php echo e($vot->Mesa); ?></td>
                        <td style="text-align: right"><?php echo e(number_format($vot->Votos,0, ".", ".")); ?></td>
                        <td>
                            <a href="" data-target="#modal-edit-<?php echo e($vot->Id_Votacion); ?>" data-toggle="modal">
                                 <button class="btn btn-danger">Editar</button>
                            </a>                        
                           
                        </td> 

                        <td>

                            <?php if(empty($vot->imagen)): ?>

                                <button class="btn btn-danger">NO</button>

                            <?php else: ?>

                                <button class="btn btn-info">SI</button>
                                <a href="<?php echo e(URL::action('ConsultaController@Acta', $vot->Id_Votacion)); ?>" target="_blank">
                                    <button class="btn btn-info">Ver</button>
                               </a>

                            <?php endif; ?>                                                                                                                      

                        </td>               
                    
                    </tr>
                    
                    <?php echo $__env->make('consulta.votos_intendente.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>

        </div>        

    </div>

</div>

<?php $__env->startPush('scripts'); ?>

<script type="text/javascript">

        $(document).ready(function() {
            var dataTable = $('#detalles').dataTable({
                //$("#detalles_.dataTables_filter").hide();                
                language: {
                    "decimal": "",
                    "emptyTable": "No hay información",
                    "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
                    "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
                    "infoFiltered": "(Filtrado de _MAX_ total entradas)",
                    "infoPostFix": "",
                    "thousands": ",",
                    "lengthMenu": "Mostrar _MENU_ Entradas",
                    "loadingRecords": "Cargando...",
                    "processing": "Procesando...",
                    "search": "Buscar:",                    
                    "zeroRecords": "Sin resultados encontrados",
                    "paginate": {
                        "first": "Primero",
                        "last": "Ultimo",
                        "next": "Siguiente",
                        "previous": "Anterior"
                    }
                }
                        
            });
        
        });
</script>

<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\JuegosySofwareinstalado\laragon\www\anr\resources\views/consulta\votos_intendente/index.blade.php ENDPATH**/ ?>